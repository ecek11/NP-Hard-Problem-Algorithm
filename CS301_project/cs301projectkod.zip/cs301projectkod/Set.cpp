
#include "Set.hpp"
#include "Graph.hpp"
#include <fstream>
//int count_true;
//int count_false;

bool global_true = false;



vector<Vertex> independent_set_brutforce;

bool check_if_edge_exist(Vertex a, Vertex b)
{
    vector<Edge> a_edges = a.edges;
    //vector<Edge> b_edges = b.edges;

    bool aa;
    bool cc;
    
    for(int i  = 0 ; i< a_edges.size() ; i++)
    {

        aa = (a_edges[i].end->vertexId == b.vertexId);
        
        //bool b = (a_edges[i].end->vertexId != a->vertexId);
        
        cc = (a_edges[i].start->vertexId == b.vertexId);
        
        //bool d = (a_edges[i].start->vertexId != a->vertexId);
        
        if(aa||cc)
            {
                return false;
                break;
            }
    }
    return true;
}
bool check_dependency(vector<Vertex>& V)
{
    bool flag=true;
    //element for independent sets
 //element number of V is greater than k
    for(int i=0;i<V.size();i++) {
        for(int j = 0;j< V.size();j++)
        {
            if((i!=j)&&!(check_if_edge_exist(V[i] , V[j])) )
            {
                flag = false;
                  break;
            }
        }

        }

if(flag == true)
{
//cout<<endl<<"Solution is true"<<endl;
    return true;
}
else
{
//cout<<endl<<"Solution is false"<<endl;
}
    return false;
}



// C++ Program to print all combination of size r in
// an array of size n
#include <stdio.h>
void combinationUtil(vector<Vertex>& arr, int n, int r,
                     int index, vector<Vertex> data, int i);
 
// The main function that prints all combinations of
// size r in arr[] of size n. This function mainly
// uses combinationUtil()
void printCombination(vector<Vertex>& arr, int n, int r)
{
    // A temporary array to store all combination
    // one by one
    vector<Vertex> data;
 
    // Print all combination using temprary array 'data[]'
    combinationUtil(arr, n, r, 0, data, 0);
}
 
/* arr[]  ---> Input Array
   n      ---> Size of input array
   r      ---> Size of a combination to be printed
   index  ---> Current index in data[]
   data[] ---> Temporary array to store current combination
   i      ---> index of current element in arr[]     */
void combinationUtil(vector<Vertex>& arr, int n, int r, int index,
                     vector<Vertex> data, int i)
{
    // Current combination is ready, print it
    if (index == r) {
        if(check_dependency(data))
        {
            global_true = true;
            independent_set_brutforce = data;
        }
//        for (int i = 0; i<data.size(); i++) {
//            cout<<data[i].vertexId;
//            cout<<" ";
//        }
//        cout<<endl;
        //printf("\n");
        return;
    }
 
    // When no more elements are there to put in data[]
    if (i >= n)
        return;
 
    // current is included, put next at next location
    if (data.size()<=index) {
        data.push_back(arr[i]);
    }
    else
    {
    data[index] = arr[i];
    }
    combinationUtil(arr, n, r, index + 1, data, i + 1);
 
    // current is excluded, replace it with next
    // (Note that i+1 is passed, but index is not
    // changed)
    combinationUtil(arr, n, r, index, data, i + 1);
}
 



void normal_function(Graph G)
{
    vector<Vertex> all = G.totalVertices;
    for(int i = all.size() ; i>0 ; i-- )
    {
         int r = i;
        int n = all.size() / 1;
         printCombination(all, n, r);
        if (global_true == true) {
            global_true = false;
            break;
        }
    }
}

Set::Set(Graph* graph) {
    _graph = graph;
    for (auto itr = graph->totalVertices.begin(); itr != graph->totalVertices.end(); itr++) {
        heap.push_back(&(*itr));
    }
    make_heap(heap.begin(), heap.end(), hasLessNeighbors());
}

//O(n)
void Set::buildIndependantSet() {
    while (_graph->numberFlagged < _graph->totalVertices.size()) {
        
        if (heap.front()->isDiscoverable) {
            set.push_back(heap.front());

            _graph->flagVertexAndNeighbours(heap.front());
        }
        pop_heap(heap.begin(), heap.end(), hasLessNeighbors());
                heap.pop_back();

    }
}


void Set::printSet() {

    ifstream file;
    ofstream writer;
    file.open("ratio_bound.txt");
    if(file.fail())
    {
        writer.open("ratio_bound.txt");
    }
    else{

       writer.open("ratio_bound.txt", std::ios_base::app);
    }
    
    

    normal_function(*_graph);
    
    
    //for ratio bound
    //double independet_size = independent_set_brutforce.size();
    //writer << independet_size/set.size()<<" ";
    
    
    if (independent_set_brutforce.size() == set.size()) { //for accuracy correctness
        //cout<<"dogru bulunmus"<<endl<<endl;
        //cout<<1;
        writer<<1;

    }
    else
    {
        //cout<<"yanlis"<<endl<<endl;
        //cout<<0;
        printSet();
        writer<<0;
    }
    file.close();
    writer.close();
    
    
    
    
}

