//
//  Sett.hpp
#ifndef SET_HPP
#define SET_HPP

#include <vector>
#include <algorithm>

#include "Graph.hpp"


using namespace std;

struct hasLessNeighbors {
    bool operator()(const Vertex* v1, const Vertex* v2)const {
        return v1->edges.size() > v2->edges.size();
    }
};


class Set {
    

public:
    Set(Graph*);
    
    void buildIndependantSet();
    void printSet();
    
    void Vertex_Set();
    
    
    
private:
    //void makeIndependantVertex(vector<int> &line);
    Graph* _graph;
    vector<Vertex*> heap;
    vector<Vertex*> set;
    
    
    
    
    

};

#endif
