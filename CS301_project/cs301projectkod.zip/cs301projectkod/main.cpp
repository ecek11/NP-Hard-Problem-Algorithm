//
//  main.cpp
//  Maximum Independent Set
//
//  Created by Emil Shirima on 4/2/16.
//  Copyright © 2016 Emil Shirima. All rights reserved.
//

#include <iostream>
#include <ctime>
#include "Graph.hpp"
#include "Edge.hpp"
#include "Set.hpp"
#include <fstream>
#include <string>
#include <cmath>
#include <stdlib.h>
#include <vector>
#include <fstream>
#include <sstream>


using namespace std;





string line = "";
void GenerateRandomGraphs(int e,int N) {
   int i, j, edge[e][2], count;
   i = 0;
   // generate a connection between two random numbers, for //sample a small case, limit the number of vertex to 10.
    
   while(i < e) {
       
      edge[i][0] = rand()%N+1;
      edge[i][1] = rand()%N+1;
      i++;
   }


   for(i = 0; i < N; i++) {
      count = 0;
      //cout<<"\n\t"<<i+1<<"-> { ";

       vector<int> birol;
       vector<int> ikiol;
         for(j = 0; j < e; j++) {
            if(edge[j][0] == i+1) {
               int bir = edge[j][1];
               count++;
                birol.push_back(bir);
            }
            else if(edge[j][1] == i+1) {
               //cout<<edge[j][0];
                int iki =edge[j][0];
                ikiol.push_back(iki);
                
               count++;
            }
            //Print “Isolated vertex” for the vertex having zero degree.
            else if(j == e-1 && count == 0){}
               //cout<<"Isolated Vertex!";
                
                 
         }
       line+="\n" + to_string(count);
       for (int i = 0; i< birol.size(); i++) {
           line+=" " + to_string(birol[i] - 1);
       }
       for (int i = 0; i< ikiol.size(); i++) {
           line+=" " + to_string(ikiol[i] - 1);
       }
      //cout<<" }";
       
      
       
   }
}





double calculateSD(double data[], int size)
{
    double sum = 0.0, mean, standardDeviation = 0.0;

    int i;

    for(i = 0; i < size; ++i)
    {
        sum += data[i];
    }

    mean = sum/size;

    for(i = 0; i < size; ++i)
        standardDeviation += (data[i] - mean)*(data[i] - mean);

    return sqrt(standardDeviation / size);
}

double calc_error(double arr[], int n){
   return calculateSD(arr, n) / sqrt(n);
}


void getRunningTime(double runningTimes[] , int N) {
double totalTime=0.0;
for(int i=0 ;i<N ;i++){
    totalTime += runningTimes[i];
}
double standarDeviation= calculateSD(runningTimes,N);
double m =totalTime /N ;
const double tval90=1.645;
const double tval95=1.96;
double sm= calc_error(runningTimes,N);
double upperMean90=m+ tval90 *sm;
double lowerMean90=m-tval90 *sm;
double upperMean95=m+ tval95 *sm;
double lowerMean95=m-tval95 *sm;
cout<<"mean time "<<m<<" ms "<<endl<<endl;
cout<<"SD "<<standarDeviation<<" ms "<<endl<<endl;
cout<<"Standard Error "<<sm<<endl<<endl;
cout<<"%90 "<<upperMean90<<" - "<<lowerMean90<<endl<<endl;
cout<<"%95 "<<upperMean95<<" - "<<lowerMean95<<endl;

    for (int l = 0; l<N; l++) {
        runningTimes = 0;
    }
}



int main(int argc, const char * argv[])
{
    

    srand(time(NULL));
    cout<<"iteration: ";
    double iteration_number;    cin>>iteration_number;
    double total_time = 0;
    double times[(int)iteration_number];
    for (int vertex_count = 6; vertex_count<9; ) {
        cout<<endl<<"Vertex number : "<<vertex_count;
    

        
    for (int m = 0; iteration_number>m; m++) {
        

    
    int N;

        N=vertex_count;
        
    
    
       int n, i ,e;
     
       e = 10;
        line+=to_string(N);
       GenerateRandomGraphs(e,N);
    //cout<<endl<<line<<endl<<endl;
    
    Graph sampleGraph = *new Graph(line);
    
	size_t currentTime = clock();
	Set testSet(&sampleGraph);
	testSet.buildIndependantSet(); // O(E + V log V)
	double time = ((double)(clock() - currentTime)/(CLOCKS_PER_SEC/1000));
        times[m] = time;
        
        
       
     
        testSet.printSet(); //this is for brute force.
        
        line="";
        

            
      
    }
        
        
        
        fstream read("ratio_bound.txt");
        double count_true=0;
        double count_false=0;
            if(!read.fail())
            {
            char c; //open for correctness
            while (read.get(c)) {
                if(c=='1')
                {
                    count_true++;
                }
                else
                {
                    count_false++;
                    //cout<<endl<<endl<<line<<endl<<endl;
                    
                }
            }
            
//            vector<double> ratio_bound;
//
//            string word;
//            double integer = 0;
//            int count= 0;
//            while(read>>word)
//            {
//                istringstream iss(word);
//                if(iss>>integer)
//                {
//                    ratio_bound.push_back(integer);
//                    count++;
//                }
//            }
//            double total_bound = 0.0;
//            for(int i = 0; i<ratio_bound.size() ; i++)
//            {
//                total_bound += ratio_bound[i];
//            }
//            cout<<endl<<"ratio bound is "<<total_bound/count<<endl;
//
            
        }
        cout<<endl<<"Black box is "<<count_true/(count_false+count_true)*100<<"%  "<<endl;



        if( remove( "ratio_bound.txt" ) != 0 )
          perror( "Error deleting file" );
        else
          puts( " \nFile successfully deleted" );

//    //calculate mean
//
//    for (int l = 0; l<iteration_number; l++) {
//        total_time += times[l];
//    }
//    double mean = total_time/iteration_number;
//
//
//    getRunningTime(times,iteration_number);
//
//

        vertex_count+=1;


    }
    

    return 0;
}
